# Gym Coach App

AI-powered personal workout coach. Built with React + Vite.

## Deploy to Vercel (5 minutes)

### Step 1 — Get an Anthropic API key
1. Go to console.anthropic.com
2. Sign up / log in
3. Go to API Keys → Create Key
4. Copy the key (starts with sk-ant-)

### Step 2 — Put code on GitHub
1. Go to github.com and create a free account if you don't have one
2. Click + → New repository → name it "gym-coach"
3. Make it Public → Create repository
4. Upload all files from this folder to the repo
   (drag and drop them into the GitHub web interface)

### Step 3 — Deploy on Vercel
1. Go to vercel.com → Sign up with GitHub
2. Click "Add New Project"
3. Import your gym-coach repository
4. Before deploying, click "Environment Variables"
5. Add: VITE_ANTHROPIC_API_KEY = your key from Step 1
6. Click Deploy

### Step 4 — Done
Vercel gives you a URL like gym-coach-xyz.vercel.app
Share that with anyone — no Claude account needed.

## Local development
npm install
npm run dev
